-- LevelGuide Waypoint: maps pfQuest zone names to WoW: Forever 16001 UiMapIDs,
-- sets native C_Map + C_SuperTrack map pins, optional TomTom bridge, or text coord fallback.

local GL = LevelGuide
local W = {}
GL.Waypoint = W

local lastTomTomUid = nil

-- Standard Classic/Forever UiMapIDs (source: Wowpedia UiMapID)
W.ZONE_TO_UIMAP = {
  ["Durotar"] = 1411,
  ["Mulgore"] = 1412,
  ["The Barrens"] = 1413,
  ["Alterac Mountains"] = 1416,
  ["Arathi Highlands"] = 1417,
  ["Badlands"] = 1418,
  ["Blasted Lands"] = 1419,
  ["Tirisfal Glades"] = 1420,
  ["Silverpine Forest"] = 1421,
  ["Western Plaguelands"] = 1422,
  ["Eastern Plaguelands"] = 1423,
  ["Hillsbrad Foothills"] = 1424,
  ["The Hinterlands"] = 1425,
  ["Dun Morogh"] = 1426,
  ["Searing Gorge"] = 1427,
  ["Burning Steppes"] = 1428,
  ["Elwynn Forest"] = 1429,
  ["Deadwind Pass"] = 1430,
  ["Duskwood"] = 1431,
  ["Darkshire"] = 1431,
  ["Loch Modan"] = 1432,
  ["Redridge Mountains"] = 1433,
  ["Stranglethorn Vale"] = 1434,
  ["Swamp of Sorrows"] = 1435,
  ["Westfall"] = 1436,
  ["Wetlands"] = 1437,
  ["Teldrassil"] = 1438,
  ["Darkshore"] = 1439,
  ["Ashenvale"] = 1440,
  ["Thousand Needles"] = 1441,
  ["Stonetalon Mountains"] = 1442,
  ["Desolace"] = 1443,
  ["Feralas"] = 1444,
  ["Dustwallow Marsh"] = 1445,
  ["Tanaris"] = 1446,
  ["Azshara"] = 1447,
  ["Felwood"] = 1448,
  ["Un'Goro Crater"] = 1449,
  ["Moonglade"] = 1450,
  ["Silithus"] = 1451,
  ["Winterspring"] = 1452,
  ["Stormwind City"] = 1453,
  ["Orgrimmar"] = 1454,
  ["Ironforge"] = 1455,
  ["Thunder Bluff"] = 1456,
  ["Darnassus"] = 1457,
  ["Undercity"] = 1458,
}

function W.Clear()
  if lastTomTomUid and TomTom and TomTom.RemoveWaypoint then
    pcall(TomTom.RemoveWaypoint, TomTom, lastTomTomUid)
    lastTomTomUid = nil
  end
  if GL.Arrow and GL.Arrow.Clear then GL.Arrow.Clear() end
  if GL.MinimapTrail and GL.MinimapTrail.Clear then GL.MinimapTrail.Clear() end
  if C_Map and C_Map.ClearUserWaypoint then
    pcall(C_Map.ClearUserWaypoint)
  end
end

-- target = { npcName, pfZoneId, x_0_100, y_0_100 }
function W.SetForTarget(target, zoneName, title)
  if not target or not target[3] or not target[4] then
    return false, "No coordinates available for this step."
  end
  local x, y = target[3], target[4]
  local mapId = zoneName and W.ZONE_TO_UIMAP[zoneName] or nil
  local label = (title or "LevelGuide") .. " - " .. tostring(target[1] or "")
  if GL.Arrow and GL.Arrow.SetTarget then
    GL.Arrow.SetTarget(mapId, zoneName, x, y, title, target[1])
  end
  if GL.MinimapTrail and GL.MinimapTrail.SetTarget then
    GL.MinimapTrail.SetTarget(mapId, zoneName, x, y)
  end
  local useTomTom = GL.db and GL.db.settings and GL.db.settings.useTomTom

  -- 1. Optional TomTom integration (no conflict if TomTom is absent)
  if useTomTom and mapId and TomTom and TomTom.AddWaypoint then
    if lastTomTomUid and TomTom.RemoveWaypoint then
      pcall(TomTom.RemoveWaypoint, TomTom, lastTomTomUid)
    end
    local ok, uid = pcall(TomTom.AddWaypoint, TomTom, mapId, x / 100, y / 100, {
      title = label,
      persistent = false,
      minimap = true,
      world = true,
    })
    if ok and uid then
      lastTomTomUid = uid
      return true, string.format("TomTom: %s (%.1f, %.1f)", tostring(zoneName), x, y)
    end
  end

  -- 2. Native WoW: Forever 16001 C_Map + C_SuperTrack pin
  if mapId and C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates then
    local okPt, pt = pcall(UiMapPoint.CreateFromCoordinates, mapId, x / 100, y / 100)
    if okPt and pt then
      local okSet = pcall(C_Map.SetUserWaypoint, pt)
      if okSet then
        if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
          pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
        end
        return true, string.format("Map Pin: %s (%.1f, %.1f)", tostring(zoneName), x, y)
      end
    end
  end

  -- 3. Text coordinate fallback
  return false, string.format("Coords: %s (%.1f, %.1f)", tostring(zoneName or "?"), x, y)
end
