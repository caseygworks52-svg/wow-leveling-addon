-- LevelGuide ActionBar: Zero-taint SecureActionButtonTemplate for 1-click Quest Mob/NPC Targeting
-- and Usable Quest Item activation. All attribute updates defer cleanly until PLAYER_REGEN_ENABLED.

local GL = LevelGuide
local AB = {}
GL.ActionBar = AB

AB.targetBtn = nil
AB.itemBtn = nil
AB.pendingTargetName = nil
AB.pendingItemId = nil

local function extractTargetName(step)
  if not step then return nil end
  if step.kind == "PICKUP" or step.kind == "TURNIN" then
    if step.target and type(step.target[1]) == "string" and step.target[1] ~= "" then
      return step.target[1]
    end
  elseif step.kind == "OBJECTIVE" then
    -- 1. Prefer QuestieDB live spawn name if available
    if step.target and not step.targetIsTurnIn and type(step.target[1]) == "string" then
      local clean = string.gsub(step.target[1], "%s*%(Drop Candidate%)$", "")
      if clean ~= "" then return clean end
    end
    -- 2. Parse clean monster name from live quest log objective text (e.g. "Kobold Vermin slain: 4/10")
    if GL.state and GL.state.log and step.ids and step.ids[1] then
      for _, e in ipairs(GL.state.log) do
        if e.id == step.ids[1] and e.objectives then
          for _, o in ipairs(e.objectives) do
            if not o.finished and type(o.text) == "string" then
              local mob = string.match(o.text, "^(.-)%s+slain:")
                or string.match(o.text, "^(.-)%s+killed:")
                or string.match(o.text, "^(.-):%s*%d+/%d+")
              if mob and mob ~= "" then return mob end
            end
          end
        end
      end
    end
  end
  return nil
end

local function findUsableQuestItemInBags()
  if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemQuestInfo then
    return nil
  end
  for bag = 0, 4 do
    local okS, slots = pcall(C_Container.GetContainerNumSlots, bag)
    if okS and type(slots) == "number" then
      for slot = 1, slots do
        local okQ, qInfo = pcall(C_Container.GetContainerItemQuestInfo, bag, slot)
        qInfo = okQ and GL.Compat and GL.Compat.SafeTable(qInfo) or nil
        if qInfo and (qInfo.isQuestItem or qInfo.questID) then
          local okI, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
          info = okI and GL.Compat and GL.Compat.SafeTable(info) or nil
          local itemId = info and GL.Compat.SafeNumber(info.itemID, nil) or nil
          if itemId and C_Item and C_Item.GetItemSpell then
            local okSp, spellName = pcall(C_Item.GetItemSpell, itemId)
            if okSp and spellName then
              return itemId, info.itemName or ("Item #" .. tostring(itemId))
            end
          end
        end
      end
    end
  end
  return nil
end

function AB.Create(parentFrame)
  if AB.targetBtn or not parentFrame or not CreateFrame then return end

  -- Secure 1-click Target Mob/NPC button (clickable even in combat!)
  local tb = CreateFrame("Button", "LevelGuideTargetButton", parentFrame, "SecureActionButtonTemplate,BackdropTemplate")
  tb:SetSize(165, 22)
  tb:SetPoint("TOPLEFT", parentFrame, "BOTTOMLEFT", 0, -4)
  tb:RegisterForClicks("AnyUp", "AnyDown")
  tb:SetAttribute("type", "macro")
  tb:SetAttribute("macrotext", "")
  if GL.Theme then GL.Theme.StyleFrame(tb, true) end

  local tfs = tb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  tfs:SetPoint("CENTER", 0, 0)
  tfs:SetWidth(155)
  tfs:SetText("Target: —")
  tb.label = tfs
  tb:Hide()
  AB.targetBtn = tb

  -- Secure 1-click Usable Quest Item button
  local ib = CreateFrame("Button", "LevelGuideQuestItemButton", parentFrame, "SecureActionButtonTemplate,BackdropTemplate")
  ib:SetSize(150, 22)
  ib:SetPoint("LEFT", tb, "RIGHT", 6, 0)
  ib:RegisterForClicks("AnyUp", "AnyDown")
  ib:SetAttribute("type", "item")
  ib:SetAttribute("item", "")
  if GL.Theme then GL.Theme.StyleFrame(ib, true) end

  local ifs = ib:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  ifs:SetPoint("CENTER", 0, 0)
  ifs:SetWidth(140)
  ifs:SetText("Use Item")
  ib.label = ifs
  ib:Hide()
  AB.itemBtn = ib
end

function AB.ApplyPending()
  if GL.Compat and GL.Compat.InCombat() then return end

  if AB.targetBtn then
    local name = AB.pendingTargetName
    if name and name ~= "" then
      local safeName = string.gsub(name, "[\r\n]", " ")
      AB.targetBtn:SetAttribute("macrotext", "/cleartarget [dead][noexists]\n/target " .. safeName)
      AB.targetBtn.label:SetText("|cfff0c252Target:|r " .. string.sub(safeName, 1, 18))
      AB.targetBtn:Show()
    else
      AB.targetBtn:SetAttribute("macrotext", "")
      AB.targetBtn:Hide()
    end
  end

  if AB.itemBtn then
    local itemId = AB.pendingItemId
    if itemId then
      AB.itemBtn:SetAttribute("item", "item:" .. tostring(itemId))
      AB.itemBtn.label:SetText("|cff55ff55Use:|r " .. string.sub(tostring(AB.pendingItemName or "Quest Item"), 1, 16))
      AB.itemBtn:Show()
    else
      AB.itemBtn:SetAttribute("item", "")
      AB.itemBtn:Hide()
    end
  end
end

function AB.UpdateForStep(step)
  if not AB.targetBtn and GL.UI and GL.UI.frame then
    AB.Create(GL.UI.frame)
  end
  AB.pendingTargetName = extractTargetName(step)
  local qItemId, qItemName = findUsableQuestItemInBags()
  AB.pendingItemId = qItemId
  AB.pendingItemName = qItemName
  AB.ApplyPending()
end
