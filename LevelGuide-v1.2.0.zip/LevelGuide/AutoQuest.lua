-- LevelGuide AutoQuest: optional Shift-bypassable Auto-Accept & Auto-Turn-In.
-- NEVER auto-picks multi-choice rewards (so you always see Rewards.lua advice).
-- Automatically yields if Dialogue UI is handling dialogue unless user explicitly enables /guide auto on.

local GL = LevelGuide
local AQ = {}
GL.AutoQuest = AQ

local function shouldRun()
  if IsShiftKeyDown and IsShiftKeyDown() then return false end
  if GL.Compat and GL.Compat.InCombat() then return false end
  if not GL.db or not GL.db.settings or not GL.db.settings.autoQuest then return false end
  return true
end

function AQ.OnQuestDetail()
  if not shouldRun() then return end
  if AcceptQuest then pcall(AcceptQuest) end
end

function AQ.OnQuestProgress()
  if not shouldRun() then return end
  if IsQuestCompletable and IsQuestCompletable() and CompleteQuest then
    pcall(CompleteQuest)
  end
end

function AQ.OnQuestComplete()
  if not shouldRun() then return end
  local choices = (GetNumQuestChoices and GetNumQuestChoices()) or 0
  -- NEVER auto-select when there are 2+ reward choices (preserves Rewards.lua advisor!)
  if choices <= 1 and GetQuestReward then
    pcall(GetQuestReward, choices == 1 and 1 or nil)
  end
end
