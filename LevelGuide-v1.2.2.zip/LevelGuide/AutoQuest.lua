-- LevelGuide AutoQuest: optional Shift-bypassable Auto-Accept & Auto-Turn-In.
-- NEVER auto-picks multi-choice rewards (so you always see Rewards.lua advice).
-- Yields when DialogueUI is loaded (it owns the dialogue UI). Also handles
-- GOSSIP_SHOW and QUEST_GREETING, which Forever/Mainline uses before QUEST_DETAIL.

local GL = LevelGuide
local AQ = {}
GL.AutoQuest = AQ

local function shouldRun()
  if IsShiftKeyDown and IsShiftKeyDown() then return false end
  if GL.Compat and GL.Compat.InCombat() then return false end
  if not GL.db or not GL.db.settings or not GL.db.settings.autoQuest then return false end
  if GL.Integrations and GL.Integrations.detected and GL.Integrations.detected.DialogueUI then
    return false
  end
  return true
end

function AQ.OnQuestDetail()
  if not shouldRun() then return end
  if AcceptQuest then pcall(AcceptQuest) end
end

function AQ.OnQuestProgress()
  if not shouldRun() then return end
  if IsQuestCompletable and IsQuestCompletable() and CompleteQuest then
    pcall(CompleteQuest)
  end
end

function AQ.OnQuestComplete()
  if not shouldRun() then return end
  local choices = (GetNumQuestChoices and GetNumQuestChoices()) or 0
  -- NEVER auto-select when there are 2+ reward choices (preserves Rewards.lua advisor!)
  if choices <= 1 and GetQuestReward then
    pcall(GetQuestReward, choices == 1 and 1 or nil)
  end
end

function AQ.OnQuestGreeting()
  if not shouldRun() then return end
  local nActive = (GetNumActiveQuests and GetNumActiveQuests()) or 0
  for i = 1, nActive do
    local complete
    if GetActiveTitle then
      _, complete = GetActiveTitle(i)
    end
    if complete and SelectActiveQuest then
      pcall(SelectActiveQuest, i)
      return
    end
  end
  local nAvail = (GetNumAvailableQuests and GetNumAvailableQuests()) or 0
  if nAvail > 0 and SelectAvailableQuest then
    pcall(SelectAvailableQuest, 1)
  end
end

function AQ.OnGossipShow()
  if not shouldRun() then return end
  if not C_GossipInfo then return end
  if C_GossipInfo.GetActiveQuests and C_GossipInfo.SelectActiveQuest then
    local ok, quests = pcall(C_GossipInfo.GetActiveQuests)
    if ok and type(quests) == "table" then
      for _, q in ipairs(quests) do
        if q and (q.isComplete or q.complete) then
          local id = q.questID or q.questId
          if id then pcall(C_GossipInfo.SelectActiveQuest, id) return end
        end
      end
    end
  end
  if C_GossipInfo.GetAvailableQuests and C_GossipInfo.SelectAvailableQuest then
    local ok, quests = pcall(C_GossipInfo.GetAvailableQuests)
    if ok and type(quests) == "table" and quests[1] then
      local id = quests[1].questID or quests[1].questId
      if id then pcall(C_GossipInfo.SelectAvailableQuest, id) end
    end
  end
end
